// let B = parseInt(prompt("B = "));
// let C = parseInt(prompt("C = "));
// let D = parseInt(prompt("D = "));
// const calculate = (B, C, D) => {
//   let A;
//   return (A = B * C - D);
// };
// console.log("A =", calculate(B, C, D));

// let days = parseInt(prompt("Days = "));
// let hours = parseInt(prompt("Hours = "));
// const totaltime = (days, hours) => {
//   return days * 24 + hours;
// };
// console.log("Нийт цаг : ", totaltime(days, hours));

// let a = parseInt(prompt("a = "));
// let b = parseInt(prompt("b = "));
// const max = (a, b) => {
//   if (a > b) return a;
//   else if (b > a) return b;
// };
// console.log("Их тоо нь : ", max(10, 20));

// let x = parseInt(prompt("x = "));
// let y = parseInt(prompt("y = "));
// const calculateArea = (x, y) => {
//   return x * y;
// };
// console.log("Тэгш өнцөгийн талбай нь : ", calculateArea(20, 30));

// let point = parseInt(prompt("Your point = "));
// const checkPoint = (point) => {
//   if (point >= 90 && point <= 100) return "A";
//   else if (point >= 90 && point <= 100) return "A";
//   else if (point >= 80 && point <= 89) return "B";
//   else if (point >= 70 && point <= 79) return "C";
//   else if (point >= 60 && point <= 69) return "D";
//   else if (point >= 0 && point <= 59) return "F";
// };
// console.log("Үсгэн үнэлгээ : ", checkPoint(point));

// const numbers = [3, 8, 1, 12, 5, 7];
// let ih = 0;
// const findLargestElement = (numbers) => {
//   for (let i = 1; i < numbers.length; i++) {
//     if (numbers[ih] < numbers[i]) {
//       ih = i;
//     }
//   }
//   return numbers[ih];
// };
// console.log("Хамгийн их элемент нь : ", findLargestElement(numbers));

// const originalarray = [1, 2, 3, 4, 5];
// const reverseArray = (originalarray) => {
//   let reversed = [];
//   for (let i = 2; i < originalarray.length + 2; i++) {
//     reversed.push(originalarray[originalarray.length - i + 1]);
//   }
//   return reversed;
// };
// console.log("Reversed Array : ", reverseArray(originalarray));

// const unsortedArray = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5];
// const sortedArray = (unsortedArray) => {
//                 let sortedarray1 = [];
//                 for (let i =1;i<unsortedArray.length;i++){
//                                 if(unsortedArray[i] > unsortedArray[i+1]){
//                                   // unsortedArray[i] switch places with unsortedArray[i+1] and so on
//                                 }

//                 }
// };
// console.log("Эрэмблэгдсэн array : ", sortedArray(unsortedArray));

// const unsortedArray = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5];
// const sortedArray = (unsortedArray) => {
//   let sorted = [...unsortedArray];
//   for (let i = 0; i < sorted.length - 1; i++) {
//     for (let j = 0; j < sorted.length - 1 - i; j++) {
//       if (sorted[j] > sorted[j + 1]) {
//         let a = sorted[j];
//         sorted[j] = sorted[j + 1];
//         sorted[j + 1] = a;
//       }
//     }
//   }
//   return sorted;
// };
// console.log("Эрэмбэлэгдсэн array : ", sortedArray(unsortedArray));

// let number = parseInt("Палиндром тоо шалгах утгаа оруулна уу : ");
// let number = 12321;
// const isPalindrome = (number) => {};

let number = prompt("Палиндром тоо шалгах утгаа оруулна уу : ");
// let string = number.toString();
a = parseInt(string[0]);
b = parseInt(string[string.length - 1]);
if (a == b) console.log("P");
else console.log("not P");

// let number = parseInt(prompt("Палиндром тоо шалгах утгаа оруулна уу : "));
let number = 12321;


