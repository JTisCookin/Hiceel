// alert("Hello World!");

//Хэрэглэгчийн функц///////////////////////////////////////////////////////
//Функц зарлах
let a = "hi";
const testFunction = (a) => {
  alert("This is a test function");
};
//Функц дуудах
// testFunction(a);

const sum = (x, y) => {
  alert(x + y);
};
// sum(5, 10);

const add = (x) => {
  return x + 1;
};
// alert(add(5));
let z = add(6);
// alert(z);

//Анхны утгатай функц
const value = (x = 4, y) => {
  alert(x + y);
};
// value(4, 5);

// Global and local variables
let b = 14; //Global
const function1 = (x, y) => {
  let z = 2; //local
  let n = 3;
  alert("f1 " + (x + y + z + b));
};
let m = 2;
// let m = 5;
const function2 = (x, y) => {
  let n = 3;
  alert("f2 " + (n + x + y + z + b));
};
function1(3, 3);
function2(3, 3);
