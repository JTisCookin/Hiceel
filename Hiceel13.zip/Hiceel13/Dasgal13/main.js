// let jims = prompt("Жимсний нэрээ таслалаар тусгаарлан оруулаарай.");
// let jimsc = jims.split(",");
// console.log(jimsc);

// let jims2 = prompt("Жимсний нэрээ таслалаар тусгаарлан оруулаарай.");
// let jimsc2 = jims2.split(",");
// jimsc2.push("banana");
// console.log(jimsc2);

// let arr = [];
// arr.push(1, 2, 3);
// console.log(arr);

let name = prompt("Нэрнүүдээ таслалаар дугаарлан оруулаарай.");
let names = name.split(",");
alert(names.indexOf("nomin"));

// let age = prompt("Наснуудаа таслалаар дугаарлан оруулаарай.");
// let ages = age.split(",");
// console.log(ages);
// let findage = ages.find((element) => {
//   return parseInt(element) === 40;
// });
// console.log(findage);
// if (findage == 40) {
//   alert("Ийм утга байна.");
// } else {
//   alert("Ийм утга байхгүй байна.");
// }

// let color = prompt("Өнгөнүүдээ таслалаар дугаарлан оруулаарай.");
// let colors = color.split(",");
// colors.pop();
// alert(colors);

// let animal = prompt("Амьтдын нэрээ таслалаар дугаарлан оруулаарай.");
// let animals = animal.split(",");
// let spliceanimals = animals.splice(0, 2);
// alert(spliceanimals);

// let numbers = [1, 2, 3, 4];
// numbers.length = 0;
// console.log(numbers);

// let numbers2 = [1, 2, 3];
// let sumarr = [...numbers2, 4];
// console.log(sumarr);
