// //for, while loops/////////////////////////////////////////////////////////
// for (let i = 0; i <= 10; i++) {
//   console.log("For Loop iteration: " + i);
// }
// let i = 10;
// while (i > 0) {
//   i--;
//   console.log("While Loop iteration: " + i);
// }

//Array//////////////////////////////////////////////////////////////////
arr1 = [1, 3, 4, 5, "c", "d"];
console.log(arr1);

arr1.push(12, 13, 5, 67); // add element to the end of the array
console.log(arr1);

//IndexOf elementiin indexiig olno////////////////////////////////////////////////
// console.log(arr1.indexOf(5));
//Haigaad oldoogui bol -1 utga butsaana
console.log(arr1.indexOf(100));

//Find/////////////////////////////////////////////////////////////////////////
let findelement = arr1.find((element) => {
  return element === 5;
});
console.log(findelement);

let lessons = [
  { name: "Math", point: 105 },
  { name: "English", point: 100 },
  { name: "Physics", point: 67 },
];
let findlesson = lessons.find((element) => {
  return element.name === "English";
});
console.log(findlesson);

//Array elementiin ustgah///////////////////////////////////////////

// arr1.length = 0;
// console.log(arr1);

arr1.splice(3, 1); // index 3-s tsaashaa 1 element ustgah
console.log(arr1);

//pop() arrayiin suuliin elementiig ustgana
arr1.pop();
console.log(arr1);

//arrayiin element/////////////////////////////////////////////////
// console.log(arr1.slice(1, 4)); // index 1-s index 4-s umnu hurtel elementuudiig butsaana
let slicearr = arr1.slice(1, 4);
console.log(slicearr);
console.log(arr1);

//array negtgeh; spread operator//////////////////////////////////////////////////////////
let sumarr = [...arr1, ...slicearr];
console.log(sumarr);

//arrayiin elementuudiig negtgeh///////////////////////////////////////////////////////////
console.log(arr1.join(", ")); // arrayiin elementuudiig string bolgoh, elementuudiig ","-s umnu negtgej butsaana


//string utgiig array bolgoh///////////////////////////////////////////////////////////
let teststr = "Hi Hi1 Hi1"
let testarr = teststr.split("H"); // string-iig array bolgoh, string-iin elementuudiig " "-s umnu negtgej butsaana
console.log(teststr,testarr);
