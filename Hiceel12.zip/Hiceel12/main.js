console.log("Hello js world");

let a = 67;
let b = "hi";
const pi = 3.14;
let c = "hello js world";
let d = true;
let array1 = [1, 3, 4, 5];
let object1 = {
  name: "donk",
  age: 19,
  nationality: "russian",
};

console.log(a, d);
console.log(c);
console.log(array1);
console.log(object1.name, object1.age, object1.nationality);

// Арифметик +, -, *, /, **, %

// console.log(a + object1.age);
// console.log(a - object1.age);
// console.log(a * object1.age);
// console.log(a / object1.age);
// console.log(a ** object1.age);
// console.log(a % object1.age);

a = a + object1.age;
console.log(a);

// a++ => a = a + 1;
// a-- => a = a - 1;
// a+=4 => a = a + 4;
console.log((a += 4));
console.log((a = +4));
console.log(a % 3);

//promt Гараас утга (авах)

let donk;
donk = prompt("Is Donk goated?");
if (donk === "yes") {
  console.log("Correct Donk is indeed goated");
} else {
  console.log("kys 👤");
}

a = prompt("Enter a number");
console.log(a + object1.age);
console.log("a = ", a);
console.log(typeof a);

a = 50;
console.log("a = ", a);
console.log(typeof a);

//console дээр олон утга (хэвлэх)
console.log("Hello", a, "world");
console.log("Hello" + a + "world"); // string concatenation

//Өгөгдлийн төрөл хувиргах
// b = prompt("b-д утга өгнө үү");
// b = parseInt(b); // string -> number
b = parseInt(prompt("b-д утга өгнө үү")); // string -> float
console.log("a + b =", a + b);

//null - хоосон утгатай NaN undefined

//Нөвцөл шалгах операторууд ==, ===, !=, !==, >, <, >=, <=
// console.log(a > b);
if (a > b) {
  console.log("a их");
} else {
  console.log("b их");
}

if (a > b) alert("a их");
else alert("b их");

if (a > b) {
  console.log("a их");
} else if (a > pi) console.log("a их");
else console.log("b их");

let x = "50";
console.log(a == x);
// "50" == 50
console.log(a === x);
// === өгөгдлийн төрлийг нь давхар ижилхэн эсэхийг шалгадаг
