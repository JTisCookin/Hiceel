// a = prompt("a=");
// b = prompt("b=");
// console.log("a = " + a + ", b = " + b);
// let c = a;
// a = b;
// b = c;

// console.log("a = " + a + ", b = " + b);
// let x = prompt("Enter a number for x");
// let y = prompt("Enter a number for y");
// let z = prompt("Enter a number for z");
// console.log("x = " + x + ", y = " + y + ", z = " + z);
// if (x > y && x > z && y > z) console.log("x" + ">" + "y" + ">" + "z");
// else if (x > y && x > z && z > y) console.log("x" + ">" + "z" + ">" + "y");
// else if (y > x && y > z && x > z) console.log("y" + ">" + "x" + ">" + "z");
// else if (y > x && y > z && z > x) console.log("y" + ">" + "z" + ">" + "x");
// else if (z > x && z > y && x > y) console.log("z" + ">" + "x" + ">" + "y");
// else if (z > x && z > y && y > x) console.log("z" + ">" + "y" + ">" + "x");

// let day = prompt("Өдөрийн утга өгнө үү!");
// let time = prompt("цагын утга өгнө үү!");
// day = parseInt(day);
// time = parseInt(time);
// sum = day * 24 + time;
// alert("Нийт цаг: " + sum);

// let too = prompt("5 оронтой тоогоо оруулна уу");
// too = parseInt(too);
// let too1 = parseInt(too / 10000) % 10;
// let too2 = parseInt(too / 1000) % 10;
// let too3 = parseInt(too / 100) % 10;
// let too4 = parseInt(too / 10) % 10;
// let too5 = parseInt(too / 1) % 10;
// // alert("Таны оруулсан тоо: " + too1 + too2 + too3 + too4 + too5);
// alert(
//   "Таны оруулсан 5 оронтой тоо эсэргээрээ: " + too5 + too4 + too3 + too2 + too1,
// );

// let n = prompt("Enter a number n");
// n = parseInt(n);
// if (n % 2 == 0) {
//   if (n % 4 == 0) {
//     alert("Тэгш тоо, 4-т хуваагдах тоо байна");
//   } else {
//     alert("Тэгш тоо, 4-т хуваагдах тоо биш байна");
//   }
// } else {
//   if (n % 3 == 0) {
//     alert("Сондгой тоо, 3-т хуваагдах тоо байна");
//   } else {
//     alert("Сондгой тоо, 3-т хуваагдах тоо биш байна");
//   }
// }

// shul = prompt("Шөл устай хоол идэх үү?\n1. Тийм\n2. Үгүй");
// if (shul == 1) {
//   tsai = prompt("Цайтай юу?\n1. Тийм\n2. Үгүй");
//   if (tsai == 1) {
//     bansh = prompt("Банштай юу?\n1. Тийм\n2. Үгүй");
//     if (bansh == 1) alert("Банштай цай");
//     else if (bansh == 2) alert("Будаатай цай");
//   } else if (tsai == 2) {
//     ymrshul = prompt(
//       "Юутай шөл идэх вэ?\n1. Гурилтай\n2. Пүнтүүзтэй\n3. Гоймонтой\n4. Банштай\n5. Махтай\n6. Ногоотой",
//     );
//     if (ymrshul == 1) alert("Лапша");
//     else if (ymrshul == 2) alert("Хуйцай");
//     else if (ymrshul == 3) alert("Гоймонтой шөл");
//     else if (ymrshul == 4) alert("Банштай шөл");
//     else if (ymrshul == 5) alert("Хар шөл");
//     else if (ymrshul == 6) alert("Ногоотой шөл");
//   }
// } else if (shul == 2) {
//   mah = prompt("Мах нь татсан уу?\n1. Тийм\n2. Үгүй");
//   if (mah == 1) {
//     gurilbudaa = prompt("Гурилтай юу? Будаатай юу?\n1. Тийм\n2. Үгүй");
//     if (gurilbudaa == 1) {
//       yaj = prompt("Яаж болгосон бэ?\n1. Шарсан\n2. Жигнэсэн");
//       if (yaj == 1) {
//         huulgugc = prompt("Хөөлгөгч хийх үү?\n1. Тийм\n2. Үгүй");
//         if (huulgugc == 1) alert("Пирошки");
//         else if (huulgugc == 2) alert("Хуушуур");
//       } else if (yaj == 2) {
//         jigneh = prompt("Хөөлгөгч хийх үү?\n1. Тийм\n2. Үгүй");
//         if (jigneh == 1) alert("Мантуун бууз");
//         else if (jigneh == 2) alert("Бууз");
//       }
//     } else if (gurilbudaa == 2) {
//       jigneh = prompt("Өндөгтэй юу?\n1. Тийм\n2. Үгүй");
//       if (jigneh == 1) alert("Өндөгтэй бифштекс");
//       else if (jigneh == 2) alert("Тефтель");
//     }
//   } else if (mah == 2) {
//     yutai = prompt(
//       "Юутай холих вэ?\n1. Гурилтай\n2. Өндөгтэй\n3. Будаатай\n4. Ногоотой",
//     );
//     if (yutai == 1) alert("Цуйван");
//     else if (yutai == 2) alert("Өндөгтэй хуурга");
//     else if (yutai == 3) {
//       holih = prompt("Хооронд нь холих юу?\n1. Тийм\n2. Үгүй");
//       if (holih == 1) alert("Будаатай хуурга");
//       else if (holih == 2) alert("Гуляш");
//     } else if (yutai == 4) alert("Ногоотой хуурга");
//   }
// }

// password = prompt("Нууц үг оруулна уу");
// cpassword = prompt("Нууц үгээ давтан оруулна уу");
// if (password === "" || cpassword === "") alert("Нууц үг хоосон байна");
// else if (password === cpassword) alert("Нууц үг амжилттай солигдлоо");
// else if (password !== cpassword) alert("Нууц үгээ зөв давтан оруулаарай");

let x = prompt("Enter a number for x");
if (x % 3 == 0 && x % 5 == 0 && x !== "") {
  alert("FizzBuzz");
} else if (x % 3 == 0 && x !== "") {
  alert("Fizz");
} else if (x % 5 == 0 && x !== "") {
  alert("Buzz");
} else if (x % 3 != 0 && x % 5 != 0 && x % 1 == 0 && x !== "") {
  alert("Input");
} else alert("Not number");
